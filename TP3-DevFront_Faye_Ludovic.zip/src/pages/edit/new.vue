<script setup lang="ts">
import FormulaireOffreMaison from '../../components/FormulaireOffreMaison.vue'
</script>
<template>
    <FormulaireOffreMaison />
</template>
