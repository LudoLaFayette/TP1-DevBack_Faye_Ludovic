<script setup lang="ts">
    import Card from "../components/card.vue";
    import Maisons from "@/assets/Maisons.json";
    console.log(Maisons);
</script>